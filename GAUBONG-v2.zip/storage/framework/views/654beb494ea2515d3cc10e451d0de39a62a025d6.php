<?php $__env->startSection('content'); ?>
<div class="container">
    <div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4>Sản phẩm tìm kiếm</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm thấy được <?php echo e(count($products)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>

							<div class="row">
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-3">
									<div class="single-item">															
									<div class="single-item-header">
											<?php if($product->promotion_price != 0): ?>	
											<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
											<?php endif; ?>	
											<a href="<?php echo e(route('page.productDetail', $product->id)); ?>"><img src="source/image/product/<?php echo e($product->image); ?>" height= '250' alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($product->name); ?></p>
											<p class="single-item-price">
												<?php if($product->promotion_price == 0): ?>												
													<span class="flash-sale"><?php echo e(number_format($product->unit_price)); ?> VND</span>
												<?php else: ?>
													<span class="flash-del"><?php echo e(number_format($product->unit_price)); ?> VND</span>
													<span class="flash-sale"><?php echo e(number_format($product->promotion_price)); ?> VND</span>
												<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('addCart', $product->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('page.productDetail', $product->id)); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							
						</div> <!-- .beta-products-list -->

						<div class="space50">&nbsp;</div>
						
					</div>
				</div> <!-- end section with sidebar and main content -->
			</div> <!-- .main-content -->
		</div> <!-- #content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/page/search.blade.php ENDPATH**/ ?>