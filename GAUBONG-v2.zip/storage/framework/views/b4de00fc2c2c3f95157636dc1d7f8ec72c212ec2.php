<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h3 class="inner-title">Admin/Thêm mới sản phẩm</h3>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb">
                    <a href="<?php echo e(route('showProduct')); ?>">Danh sách sản phẩm</a> / <span>Thêm mới sản phẩm</span>                    
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>    
	<div class="container">
		<div id="content">			
			<form action="<?php echo e(route('postCategory')); ?>" method="post" class="beta-form-checkout" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
				<div class="row">
                    <div class="col-sm-3"></div>                  
					
                    <?php if(Session::has('success')): ?>
                        <div class='alert alert-success'><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
					<div class="col-sm-6">
						<h4>Thêm mới</h4>
						<div class="space20">&nbsp;</div>
						
						<div class="form-block">
							<label >Loại sản phẩm</label>
							<input type="text"  name='name' class="form-control" required>
						</div>                        
						<div class="form-block">
							<label >Description</label>
							<input type="text" class="form-control" name='description' >
						</div>                      
						<div class="form-block">
							<label >Hình ảnh</label>
							<input type="file" class="form-control" name='image'>
						</div>	
						<div class="space10">&nbsp;</div>									
						<div class="form-block">
                            <button type="submit" class="btn btn-primary">Thêm loại sản phẩm</button>
                            <button class="btn btn-primary" onclick="window.history.go(-1); return false;">BACK</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
            </form>           
		</div> <!-- #content -->
    </div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/category/create.blade.php ENDPATH**/ ?>