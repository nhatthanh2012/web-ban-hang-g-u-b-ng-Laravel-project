<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h3 class="inner-title">Admin/Edit loại sản phẩm</h3>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb">
                    <a href="<?php echo e(route('showProduct')); ?>">Danh sách sản phẩm</a> / <span>Edit loại sản phẩm</span>                    
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>    
	<div class="container">
		<div id="content">			
			<form action="<?php echo e(route('updateCategory', $productType->id)); ?>" method="post" class="beta-form-checkout" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
				<div class="row">
                    <div class="col-sm-3"></div>                  
					
                    <?php if(Session::has('success')): ?>
                        <div class='alert alert-success'><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
					<div class="col-sm-6">
						<h4>Chỉnh sửa</h4>
						<div class="space20">&nbsp;</div>
						
						<div class="form-block">
							<label for="your_last_name">Loại sản phẩm</label>
							<input type="text"  name='name' value='<?php echo e($productType->name); ?>' required>
						</div>                        
						<div class="form-block">
							<label >Description</label>
							<input type="text"  name='description' value='<?php echo e($productType->description); ?>' required>
						</div>                      
						<div class="form-block">
							<label for="adress">Hình ảnh</label>
							<input type="file" id="adress" name='image' value='<?php echo e($productType->image); ?>'>
						</div>										
						<div class="form-block">
                            <button type="submit" class="btn btn-primary">Edit sản phẩm</button>
                            <button class="btn btn-primary" onclick="window.history.go(-1); return false;">BACK</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
            </form>           
		</div> <!-- #content -->
    </div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\gaubong\resources\views/category/edit.blade.php ENDPATH**/ ?>