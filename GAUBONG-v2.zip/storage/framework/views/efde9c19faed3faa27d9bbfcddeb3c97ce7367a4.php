<?php $__env->startSection('content'); ?>
<div class="inner-header">	  
		<div class="container">
			<div class="pull-left">
				<h3 class="inner-title">Admin/Thêm mới sản phẩm</h3>
			</div>
			
			<div class="clearfix"></div>
		</div>
	</div>    
	<div class="container">
		<div id="content">			
			<form action="<?php echo e(route('postProduct')); ?>" method="post" class="beta-form-checkout" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
				<div class="row">
                    <div class="col-sm-3"></div>                  
					
                    <?php if(Session::has('success')): ?>
                        <div class='alert alert-success'><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
					<div class="col-sm-6">
						<h4>Thêm mới</h4>
						<div class="space20">&nbsp;</div>						
						<div class="form-block">
							<label for="your_last_name">Tên sản phẩm</label>
							<input type="text"  name='name' class="form-control" required>
						</div>                        
						<div class="form-block">
							<label >Giá gốc</label>
							<input type="text"  name='unit_price' class="form-control" required>
						</div>
                        <div class="form-block">
							<label >Giá khuyến mãi</label>
							<input type="text"  name='promotion_price' class="form-control" required>
						</div>			
						<div class="form-block">
							<label for="phone">New</label>
							<input type="text"  name='new' class="form-control" required>
						</div>						
						<div class="form-block">
                            <label for="exampleFormControlSelect1">Thể loại</label>
                            <select class="form-control" name="id_type">
                                <?php $__currentLoopData = $productType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
						</div>
						<div class="form-block">
							<label for="adress">Hình ảnh</label>							
							<input type="file" id="adress" name='image' class="form-control" required>
						</div>	
						<div class="space10">&nbsp;</div>			
						<div class="form-block">
                            <button type="submit" class="btn btn-primary">Thêm mới sản phẩm</button>
                            <button class="btn btn-primary" onclick="window.history.go(-1); return false;">Hủy</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
            </form>           
		</div> <!-- #content -->
    </div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/product/create.blade.php ENDPATH**/ ?>