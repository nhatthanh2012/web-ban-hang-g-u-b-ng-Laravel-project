<?php $__env->startSection('content'); ?>
<div class="pull-left">
    <h3 class="inner-title">Admin/Chi tiết đơn hàng</h3>
</div>
<div class="row">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Tên sản phẩm</th>
                <th scope="col">Số lượng</th>
                <th scope="col">Đơn giá</th>
                <th scope="col">Thành tiền</th>               
            </tr>
        </thead>
        <tbody>
            <?php if(count($billDetail) == 0): ?>
            <tr>
                <td colspan="5" class="text-center">Không có dữ liệu</td>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $billDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- <th scope="row"></th> -->
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($bill->product->name); ?></td>
                <td><?php echo e($bill->quantity); ?></td>
                <td><?php echo e($bill->product->unit_price); ?></td>
                <td>
                    <?php echo e(number_format($bill->quantity * $bill->product->unit_price)); ?> VND
                </td>                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <tr>
                <td colspan='4'><b>Tổng tiền</b></td>
                <td><b><?php echo e(number_format($bill_id->total)); ?> VND</b></td>
            </tr>            
        </tbody>
    </table>
    <button class="btn btn-primary" onclick="window.history.back()"> Back</button>    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/order/detail.blade.php ENDPATH**/ ?>