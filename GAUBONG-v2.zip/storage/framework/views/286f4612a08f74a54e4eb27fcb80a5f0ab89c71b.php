<?php $__env->startSection('content'); ?>
<div class="pull-left">
    <h3 class="inner-title">Admin/Danh sách đơn hàng</h3>
</div>
<div class="row">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Tên khách hàng</th>
                <th scope="col">Email</th>
                <th scope="col">Địa chỉ</th>
                <th scope="col">SDT</th>
                <th scope="col">Ngày đặt hàng</th>
                <th scope="col">Tổng tiền</th>
                <th scope="col">Phương thức thanh toán</th>
                <th>Chi tiết đơn hàng</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($bills) == 0): ?>
            <tr>
                <td colspan="9" class="text-center">Không có dữ liệu</td>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- <th scope="row"></th> -->
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($bill->customer->name); ?></td>
                <td><?php echo e($bill->customer->email); ?></td>
                <td><?php echo e($bill->customer->address); ?></td>
                <td><?php echo e($bill->customer->phone_number); ?></td>
                <td><?php echo e($bill->date_order); ?></td>
                <td><?php echo e($bill->total); ?></td>
                <td><?php echo e($bill->payment); ?></td>
                <td>
                    <a href="<?php echo e(route('showDetail', $bill->id)); ?>">Chi tiết</a>                   
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/order/show.blade.php ENDPATH**/ ?>