               
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="container">
		<div class="pull-left">
				<h3 class="inner-title">Admin/Loại sản phẩm</h3>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb">
                    <li><b><a href="<?php echo e(route('showProduct')); ?>">Danh sách sản phẩm</a></b></li> 
				   <li><b><a href="<?php echo e(route('showCategory')); ?>">Loại sản phẩm</a></b></li> 
				   <li><b><a href="<?php echo e(route('showUser')); ?>">Danh sách User</a></b></li>
				</div>
            </div>
            
			<div class="clearfix"></div>
		</div>
    </div>
        <div class="col-sm-3"></div>             					
                    <?php if(Session::has('success')): ?>
                        <div class='alert alert-success'><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
        <div class="row">                  
            <table class="table table-striped">
                <thead>
                <tr>
                <th scope="col">#</th>
                    <th scope="col">Loại sản phẩm</th>
                    <th scope="col">Description</th>
                    <th scope="col">Hình ảnh</th>                   
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($productType) == 0): ?>
                    <tr>
                        <td colspan="5" class="text-center">Không có dữ liệu</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $productType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($type->name); ?></td>
                        <td><?php echo e($type->description); ?></td>                        
                        <td>
                            <img src="source/image/product/<?php echo e($type->image); ?>" height='100'weight='100'>
                        </td>                        
                        <td><a href="<?php echo e(route('editCategory', $type->id)); ?>">Edit</a></td>
                        <td><a href="<?php echo e(route('deleteCategory', $type->id)); ?>" class="text-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="col-12">
                <div class="row">
                    <div class="col-6">
                        <a class="btn btn-primary" href="<?php echo e(route('createCategory')); ?>">Thêm mới</a>
                    </div>
                    <div class="col-6">                        
                    </div>
                    </div>
                </div>
            </div>
        <!-- Modal -->
       
    </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/category/show.blade.php ENDPATH**/ ?>