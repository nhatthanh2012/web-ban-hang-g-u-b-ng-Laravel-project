<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Loại sản phẩm / <?php echo e($productType_id->name); ?></h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="<?php echo e(route('page.home')); ?>">Trang chủ</a> / <span>Sản phẩm</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-3">
						<ul class="aside-menu">
							<?php $__currentLoopData = $productType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(route('page.productType', $type->id)); ?>"><?php echo e($type->name); ?></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<div class="col-sm-9">
						<div class="beta-products-list">
							<h4>Sản phẩm theo loại</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm thấy <?php echo e(count($productByType)); ?> sản phẩm <?php echo e($productType_id->name); ?></p>
								<div class="clearfix"></div>
							</div>

							<div class="row">
								<?php $__currentLoopData = $productByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-4">
									<div class="single-item">
										<div class="single-item-header">
										<?php if($product->promotion_price != 0): ?>	
											<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
										<?php endif; ?>	
											<a href="<?php echo e(route('page.productDetail', $product->id)); ?>"><img src="source/image/product/<?php echo e($product->image); ?>" height= '250' alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($product->name); ?></p>
											<p class="single-item-text"> Số lượt xem: <?php echo e($product->view); ?></p>
											<p class="single-item-price">
												<?php if($product->promotion_price == 0): ?>												
													<span class="flash-sale"><?php echo e(number_format($product->unit_price)); ?> VND</span>
												<?php else: ?>
													<span class="flash-del"><?php echo e(number_format($product->unit_price)); ?> VND</span>
													<span class="flash-sale"><?php echo e(number_format($product->promotion_price)); ?> VND</span>
												<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('addCart', $product->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('page.productDetail', $product->id)); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div> <!-- .beta-products-list -->

						<div class="space50">&nbsp;</div>

						<div class="beta-products-list">
							<h4>Sản phẩm khác</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm thấy được <?php echo e(count($productOthers)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>
							<div class="row">
								<?php $__currentLoopData = $productOthers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $others): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-4">
									<div class="single-item">
										<div class="single-item-header">
											<?php if($others->promotion_price != 0): ?>	
											<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
											<?php endif; ?>	
											<a href="<?php echo e(route('page.productDetail', $others->id)); ?>"><img src="source/image/product/<?php echo e($others->image); ?>" height='250' alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($others->name); ?></p>
											<p class="single-item-text"> Số lượt xem: <?php echo e($others->view); ?></p>
											<p class="single-item-price">
												<?php if($others->promotion_price == 0): ?>												
													<span class="flash-sale"><?php echo e(number_format($others->unit_price)); ?> VND</span>
												<?php else: ?>
													<span class="flash-del"><?php echo e(number_format($others->unit_price)); ?> VND</span>
													<span class="flash-sale"><?php echo e(number_format($others->promotion_price)); ?> VND</span>
												<?php endif; ?>
											</p>
										</div>
										<div class="single-item-caption">
											<a class="add-to-cart pull-left" href="<?php echo e(route('addCart', $others->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
											<a class="beta-btn primary" href="<?php echo e(route('page.productDetail', $others->id)); ?>">Chi tiết <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class='row'><?php echo e($productOthers->links()); ?></div>
							</div>
							<div class="space40">&nbsp;</div>
							
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->


			</div> <!-- .main-content -->
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/page/productType.blade.php ENDPATH**/ ?>