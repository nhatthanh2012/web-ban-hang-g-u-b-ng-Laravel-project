<?php $__env->startSection('content'); ?>
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Loại sản phẩm / <?php echo e($product->productType->name); ?></h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb font-large">
                <a href="<?php echo e(route('page.home')); ?>">Trang chủ</a> / <span>Thông tin chi tiết sản phẩm</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">
        <div class="row">
            <div class="col-sm-9">
                <div class="row">
                    <div class="col-sm-4">
                        <?php if($product->promotion_price != 0): ?>
                        <div class="ribbon-wrapper">
                            <div class="ribbon sale">Sale</div>
                        </div>
                        <?php endif; ?>
                        <img src="source/image/product/<?php echo e($product->image); ?>" height='350' weight='300' alt="">
                    </div>
                    <div class="col-sm-8">
                        <div class="single-item-body">
                            <p class="single-item-title">
                                <h4><?php echo e($product->name); ?></h4>
                            </p>
                            <p class="single-item-price">
                                <?php if($product->promotion_price == 0): ?>
                                    <span class="flash-sale"><?php echo e(number_format($product->unit_price)); ?> VND</span>
                                <?php else: ?>
                                    <span class="flash-del"><?php echo e(number_format($product->unit_price)); ?> VND</span>
                                    <span class="flash-sale"><?php echo e(number_format($product->promotion_price)); ?> VND</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="clearfix"></div>    
                        <div class="space20">&nbsp;</div>

                        <div class="single-item-desc">
                            <p></p>
                        </div>
                        <div class="space20">&nbsp;</div>

                        <p>Số lượng</p>
                        <div class="single-item-form">
                            <form action="<?php echo e(route('addCart', $product->id)); ?>" method='get' class="form-group">
                                <input class="form-block" type="number" name="num-product" value="1">
                                <button><i class="fa fa-shopping-cart"></i>Mua ngay</button>
                            </form>
                            <div class="clearfix"></div>
                        </div>
                        <div class="space20">&nbsp;</div>
                        <div>
                            <button class="btn btn-primary" onclick="window.history.go(-1); return false;">Trở
                                về</button>
                        </div>
                    </div>
                </div>

                <div class="space40">&nbsp;</div>
                <div id="wrap-inner">                    
                    <div id="product-detail">
                        <h6>Mô tả</h6>
                        <p class="text-justify">
                            <?php echo e($product->productType->description); ?>

                        </p>
                    </div>
                    <div id="comment">
                        <h6>Bình luận</h6>
                        <div class="col-md-9 comment">
                            <form method="post" action="<?php echo e(route('postComment', $product->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input required type="email" class="form-control" id="email" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="name">Tên:</label>
                                    <input required type="text" class="form-control" id="name" name="name">
                                </div>
                                <div class="form-group">
                                    <label for="cm">Bình luận:</label>
                                    <textarea required rows="5" cols='5' id="cm" class="form-control" name="content"></textarea>
                                </div>
                                <div class="form-group text-right">
                                    <button type="submit" class="btn btn-default">Gửi</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div id="comment-list">
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <ul>
                            <li class="com-title">
                               <b><?php echo e($comment['name']); ?></b> 
                                <br>
                                <span><?php echo e($comment['email']); ?></span>
                                <br>
                                <span><?php echo e(date('d/m/Y H:i', strtotime($comment['create_at']))); ?></span>
                            </li>
                            <li class="com-details">
                                <?php echo e($comment['content']); ?>

                            </li>
                        </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="space50">&nbsp;</div><br>

                <div class="beta-products-list">
                    <h4>Sản phẩm liên quan</h4>
                    <div class="row">
                        <?php $__currentLoopData = $product_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                            <div class="single-item">
                                <div class="single-item-header">
                                    <?php if($related->promotion_price != 0): ?>
                                    <div class="ribbon-wrapper">
                                        <div class="ribbon sale">Sale</div>
                                    </div>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('page.productDetail', $related->id)); ?>"><img
                                            src="source/image/product/<?php echo e($related->image); ?>" height='250' alt=""></a>
                                </div>
                                <div class="single-item-body">
                                    <p class="single-item-title"><?php echo e($related->name); ?></p>
                                    <p class="single-item-text"> Số lượt xem: <?php echo e($related->view); ?></p>
                                    <p class="single-item-price">
                                        <?php if($related->promotion_price == 0): ?>
                                        <span class="flash-sale"><?php echo e(number_format($related->unit_price)); ?> VND</span>
                                        <?php else: ?>
                                        <span class="flash-del"><?php echo e(number_format($related->unit_price)); ?> VND</span>
                                        <span class="flash-sale"><?php echo e(number_format($related->promotion_price)); ?>

                                            VND</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="single-item-caption">
                                    <a class="add-to-cart pull-left" href="<?php echo e(route('addCart', $related->id)); ?>"><i
                                            class="fa fa-shopping-cart"></i></a>
                                    <a class="beta-btn primary" href="<?php echo e(route('page.productDetail', $related->id)); ?>">Chi
                                        tiết <i class="fa fa-chevron-right"></i></a>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div> <!-- .beta-products-list -->
            </div>
            <div class="col-sm-3 aside">
                <div class="widget">
                    <h3 class="widget-title">Sản phẩm mới</h3>
                    <div class="widget-body">
                        <div class="beta-sales beta-lists">
                            <?php $__currentLoopData = $new_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="media beta-sales-item">
                                <a class="pull-left" href="<?php echo e(route('page.productDetail', $new->id)); ?>"><img
                                        src="source/image/product/<?php echo e($new->image); ?>" alt=""></a>
                                <div class="media-body">
                                    <?php echo e($new->name); ?>

                                    <br><span class="beta-sales-price" style='font-size:12px'
                                        ;><?php echo e(number_format($new->unit_price)); ?> VND</span>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div> <!-- best sellers widget -->
            </div>
        </div>
    </div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG-v2\resources\views/page/productDetail.blade.php ENDPATH**/ ?>