<?php $__env->startSection('content'); ?>
<div class='container'>
<div class="col-12" class='main'>
    <div class="container">
        <div class="pull-left">
            <h3 class="inner-title">Admin/Danh sách sản phẩm</h3>
        </div>
        <div class="col-12">
            <!-- Modal content-->
            <form action="<?php echo e(route('filterByType')); ?>" method="get">
                <?php echo csrf_field(); ?>                
                <div class="select-by-program">
                    <div class="form-group row">
                        <label class="col-sm-5 col-form-label border-right">Lọc sản phẩm theo loại</label>
                        <div class="col-sm-7">
                            <select class="custom-select w-100" name="id_type">
                                <option value="">Chọn loại sản phẩm</option>
                                <?php $__currentLoopData = $productType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($typeFilter)): ?>
                                        <?php if($type->id == $typeFilter->id): ?>
                                        <option value="<?php echo e($type->id); ?>" selected><?php echo e($type->name); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                        <?php endif; ?>
                                        <?php else: ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <!-- </form> -->
                </div>
                <!--End-->

                <div class="modal-footer">
                    <button type="submit" id="submitAjax" class="btn btn-primary">Chọn</button>
                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Hủy</button>
                </div>
        </div>
        </form>
    </div>  

    <div class="clearfix"></div>
</div>

</div>
<div class="col-sm-3"></div>
<?php if(Session::has('success')): ?>
<div class='alert alert-success'><?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
<div class="row">
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Tên sản phẩm</th>
                <th scope="col">Thể loại</th>
                <th scope="col">Giá gốc</th>
                <th scope="col">giá khuyến mãi</th>
                <th scope="col">Hình ảnh</th>
                <th scope="col">New</th>
                <th scope="col">View</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($products) == 0): ?>
            <tr>
                <td colspan="7" class="text-center">Không có dữ liệu</td>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- <th scope="row"></th> -->
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->productType->name); ?></td>
                <td><?php echo e($product->unit_price); ?></td>
                <td><?php echo e($product->promotion_price); ?></td>
                <td>
                    <img src="source/image/product/<?php echo e($product->image); ?>" height='100' weight='100' alt="">
                </td>
                <td><?php echo e($product->new); ?></td>
                <td><?php echo e($product->view); ?></td>
                <td><a href="<?php echo e(route('editProduct', $product->id)); ?>">Edit</a>
                    <a href="<?php echo e(route('deleteProduct', $product->id)); ?>" class="text-danger"
                        onclick="return confirm('Bạn chắc chắn muốn xóa?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="col-12">
        <div class="row">
            <div class="col-6">
                <a class="btn btn-primary" href="<?php echo e(route('createProduct')); ?>">Thêm mới</a>
                <a class="btn btn-primary" href="<?php echo e(route('showCategory')); ?>">loại sản phẩm</a>
            </div>
            <div class="col-6">
                <div class="pagination float-right">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG\resources\views/product/show.blade.php ENDPATH**/ ?>