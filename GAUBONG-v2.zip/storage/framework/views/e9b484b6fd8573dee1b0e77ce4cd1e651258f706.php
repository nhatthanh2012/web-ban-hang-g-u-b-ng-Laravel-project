<?php $__env->startSection('content'); ?>
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">Thông tin giỏ hàng</h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb font-large">
                <a href="index.html">Home</a> / <span>Giỏ hàng</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div class="container">
    <div id="content">

        <div class="table-responsive">
            <!-- Shop Products Table -->
            <table class="shop_table beta-shopping-cart-table" cellspacing="0">
                <thead>
                    <tr>
                        <th class="product-name">Sản phẩm</th>
                        <th class="product-image">Hình ảnh</th>
                        <th class="product-quantity">Số lượng</th>
                        <th class="product-price">Đơn giá</th>
                        <th class="product-subtotal">Thành tiền</th>
                        <th class="product-remove">Remove</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(Session::has('cart')): ?>
                    <?php $__currentLoopData = $product_cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="cart_item">
                        <td class="product-name">
                            <div class="media">
                                <div class="media-body">
                                    <p class="font-large table-title"><?php echo e($product['item']['name']); ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="product-image">
                            <div class="media">
                                <img class="pull-left" src="source/image/product/<?php echo e($product['item']['image']); ?>" alt=""
                                    height='100px' width="100px">
                            </div>
                        </td>
                        <td>
                            <div class="product-quantity">
                                <input class="form-control" type="number" value="<?php echo e($product['qty']); ?>">
                            </div>
                        </td>

                        <td class="product-price">
                            <span class="amount">
                                <?php if($product['item']['promotion_price'] == 0): ?>
                                <?php echo e(number_format($product['item']['unit_price'])); ?> VND
                                <?php else: ?>
                                <?php echo e(number_format($product['item']['promotion_price'])); ?> VND
                                <?php endif; ?>
                            </span>
                        </td>

                        <td class="product-subtotal">
                            <span class="amount">
                                <?php if($product['item']['promotion_price'] == 0): ?>
                                <?php echo e(number_format($product['qty'] * $product['item']['unit_price'])); ?> VND
                                <?php else: ?>
                                <?php echo e(number_format($product['qty'] * $product['item']['promotion_price'])); ?> VND
                                <?php endif; ?>
                            </span>
                        </td>
                        <td class="product-remove">
                            <a href="<?php echo e(route('deleteItem',$product['item']['id'] )); ?>" class="remove"
                                title="Remove this item"><i class="fa fa-trash-o"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6" class="actions">                           
                            <a href="<?php echo e(route('getCheckout')); ?>" class="beta-btn primary text-center">Đặt hàng <i
                                    class="fa fa-chevron-right"></i></a>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <?php endif; ?>
            <!-- End of Shop Table Products -->
        </div>
        <!-- Cart Collaterals -->
        <div class="cart-collaterals">

            <form class="shipping_calculator pull-left" action="#" method="post">

                <section class="shipping-calculator-form " style="display: none;">

                    <p class="form-row form-row-wide">
                        <input type="hidden" name="calc_shipping_state" id="calc_shipping_state"
                            placeholder="State / county">
                    </p>
                    <p class="form-row form-row-wide">
                        <input type="text" class="input-text" value="" placeholder="Postcode / Zip"
                            name="calc_shipping_postcode" id="calc_shipping_postcode">
                    </p>
                    <p><button type="submit" name="calc_shipping" value="1" class="beta-btn primary pull-right">Update
                            Totals</button></p>
                </section>
            </form>

            <div class="cart-totals pull-right">
                <div class="cart-totals-row">
                    <h5 class="cart-total-title">Tổng tiền</h5>
                </div>

                <div class="cart-totals-row" style=" text-align: center">
                    <span >
                       <b> <?php if(Session::has('cart')): ?><?php echo e(number_format($totalPrice)); ?> VND <?php else: ?> 0 <?php endif; ?>  </b>
                    </span>
                </div>
            </div>

            <div class="clearfix"></div>
        </div>
        <!-- End of Cart Collaterals -->
        <div class="clearfix"></div>

    </div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GAUBONG-v2\resources\views/page/shoppingCart.blade.php ENDPATH**/ ?>