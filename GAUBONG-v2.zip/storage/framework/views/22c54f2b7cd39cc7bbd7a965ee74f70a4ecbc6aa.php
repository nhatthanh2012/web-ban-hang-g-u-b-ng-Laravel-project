                
<?php $__env->startSection('content'); ?>
<div class="col-12">
       
    <div class="container">
		<div class="pull-left">
				<h3 class="inner-title">Admin/User</h3>
			</div>
			<div class="pull-right">
                <ul>
				<div class="beta-breadcrumb">                 
                    <li><b><a href="<?php echo e(route('showProduct')); ?>">Danh sách sản phẩm</a></b></li> 
				   <li><b><a href="<?php echo e(route('showCategory')); ?>">Loại sản phẩm</a></b></li> 
				   <li><b><a href="<?php echo e(route('showUser')); ?>">Danh sách User</a></b></li>
                </div>
                </ul>
            </div>
            
			<div class="clearfix"></div>
		</div>
    </div>
        <div class="col-sm-3"></div>             					
                    <?php if(Session::has('success')): ?>
                        <div class='alert alert-danger'><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
        <div class="row">                  
            <table class="table table-striped">
                <thead>
                <tr>
                <th scope="col">#</th>
                    <th scope="col">Fullname</th>
                    <th scope="col">Email</th>
                    <th scope="col">Password</th>  
                    <th scope="col">Phone</th>  
                    <th scope="col">Address</th>               
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php if(count($users) == 0): ?>
                    <tr>
                        <td colspan="5" class="text-center">Không có dữ liệu</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e(++$key); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->password); ?></td>  
                        <td><?php echo e($user->phone); ?></td>  
                        <td><?php echo e($user->address); ?></td>                                                              
                        <td><a href="<?php echo e(route('editUser', $user->id)); ?>">Edit</a></td>
                        <td><a href="<?php echo e(route('deleteUser', $user->id)); ?>" class="text-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="col-12">                
            </div>
        <!-- Modal -->       
    </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\gaubong\resources\views/user/show.blade.php ENDPATH**/ ?>