@extends('admin.layouts.master')

@section('title')
	Trang Chủ
@endsection

@section('content')
	<h1 class="h3 mb-4 text-gray-800">Trang Chủ</h1>
@endsection